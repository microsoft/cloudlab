# Azure-ActiveDirectory-AppProxy-DemoSuite
Contains the Scripts and Content for Azure AD App Proxy Demo

This repository contains PS1 powerShell Scripts for setting up content for the Azure Active Directory App Proxy Demo
You can simply execute the PS1 script on a vanilla Windows Server 2012 R2 and it will configure the IIS and Web Application to be used for labs and demo.
In the first release it publishes the below sample

•	Windows Integrated Authentication

•	Forms Based Application

